package com.example.apiredesparcialfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiredesparcialfinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiredesparcialfinalApplication.class, args);
	}

}
